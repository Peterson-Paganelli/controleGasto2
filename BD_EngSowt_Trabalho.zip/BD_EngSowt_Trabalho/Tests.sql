-- criaçao de conta
call P_CriacaoDeConta ('joao', '76545678232', '47900000100', 'joao@gmail.com', '0989765'); 

-- validaçao de senha
select validador_senhaeemail('Pertersom@gmail.com', '211')

-- tabela dos dados pessoal
select * from dados_pessoal

-- adiçao de gastos a uma tabela de gastos
call P_AdicaoTabelaGastos(1, 700200, '2026-10-03', 'skin nova do pyke');

-- ver oque tem na tabela de gastos 
select t.id_gastos,t.id_dadospessoal, d.nome, t.valor, t.data_tabela, t.descricao from Tabela_gastos t
join dados_pessoal d on d.id_dadopessoal = t.id_dadospessoal 
order by t.id_dadospessoal;

-- excluir tabela de gastos
call P_ExcluirTabelaGastos(2,1)


