
-- drop table dados_pessoal
create table dados_pessoal (
	id_dadopessoal serial primary key,
	nome varchar,
	cpf varchar(12) unique,
	numero_telefone varchar unique,
	email varchar unique,
	senha varchar
);

--drop function Validador_senhaEemail
create function Validador_senhaEemail(p_email varchar, p_senha varchar)
returns boolean
language plpgsql
as $$
begin
	if p_senha = (select senha from dados_pessoal where email = lower(p_email)) then
		raise notice 'Entrando';
		return true;
	end if;
	raise notice 'Senha ou email incorreto!';
	return false;
	
end;
$$;

select * from dados_pessoal
















