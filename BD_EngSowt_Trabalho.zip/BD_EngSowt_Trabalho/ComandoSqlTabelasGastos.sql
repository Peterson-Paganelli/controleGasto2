
create table Tabela_gastos (
	id_Gastos serial primary key,
	id_dadospessoal int,
	valor float,
	data_tabela date,
	descricao text,

	constraint fk_DadosPessoal foreign key (id_dadospessoal) references dados_pessoal(id_dadopessoal)
);
-- adicionar na tabela de gastos
create procedure P_AdicaoTabelaGastos(p_id_dadospessoal int, p_valor float, p_data_tabela date, p_descricao text)
language plpgsql
as $$
begin
	insert into Tabela_gastos (id_dadospessoal, valor , data_tabela , descricao)
	values (p_id_dadospessoal, p_valor , p_data_tabela , p_descricao);
end;
$$;

-- procedure excluir tabela de gastos
create procedure P_ExcluirTabelaGastos(p_id_Gastos int, p_id_dadospessoal int)
language plpgsql
as $$
begin
	delete from Tabela_gastos where p_id_dadospessoal = id_dadospessoal and p_id_Gastos = id_Gastos;
end;
$$;



