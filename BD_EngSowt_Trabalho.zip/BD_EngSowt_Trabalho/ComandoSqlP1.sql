
-- drop procedure P_CriacaoDeConta
create procedure P_CriacaoDeConta(p_nome varchar, p_cpf varchar, p_numero_telefone varchar, p_email varchar, p_senha varchar)
language plpgsql
as $$
begin
	insert into dados_pessoal (nome, cpf, numero_telefone, email, senha)
	values (p_nome, p_cpf, p_numero_telefone, lower(p_email), p_senha);
end;
$$;
